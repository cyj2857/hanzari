import VCombobox from './VCombobox'

export { VCombobox }
export default VCombobox
