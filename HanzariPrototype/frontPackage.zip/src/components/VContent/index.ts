import VContent from './VContent'

export { VContent }

export default VContent
