import VAutocomplete from './VAutocomplete'

export { VAutocomplete }
export default VAutocomplete
