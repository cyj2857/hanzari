import VAlert from './VAlert'

export { VAlert }
export default VAlert
