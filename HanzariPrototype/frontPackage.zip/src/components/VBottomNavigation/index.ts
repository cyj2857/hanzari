import VBottomNavigation from './VBottomNavigation'

export { VBottomNavigation }
export default VBottomNavigation
