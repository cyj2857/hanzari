import VBanner from './VBanner'

export { VBanner }
export default VBanner
