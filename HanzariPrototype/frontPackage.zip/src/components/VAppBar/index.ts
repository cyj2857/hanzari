import VAppBar from './VAppBar'
import VAppBarNavIcon from './VAppBarNavIcon'

export { VAppBar, VAppBarNavIcon }

export default {
  $_vuetify_subcomponents: {
    VAppBar,
    VAppBarNavIcon,
  },
}
