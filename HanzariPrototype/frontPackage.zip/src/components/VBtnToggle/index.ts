import VBtnToggle from './VBtnToggle'

export { VBtnToggle }
export default VBtnToggle
