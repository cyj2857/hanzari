import { createSimpleFunctional } from '../../util/helpers'

export default createSimpleFunctional('v-breadcrumbs__divider', 'li')
