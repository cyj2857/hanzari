import VBadge from './VBadge'

export { VBadge }
export default VBadge
