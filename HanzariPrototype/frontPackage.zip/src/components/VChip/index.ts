import VChip from './VChip'

export { VChip }
export default VChip
