"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _vue = _interopRequireDefault(require("vue"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* @vue/component */
var _default = _vue.default.extend({
  name: 'returnable',
  props: {
    returnValue: null
  },
  data: function data() {
    return {
      isActive: false,
      originalValue: null
    };
  },
  watch: {
    isActive: function isActive(val) {
      if (val) {
        this.originalValue = this.returnValue;
      } else {
        this.$emit('update:return-value', this.originalValue);
      }
    }
  },
  methods: {
    save: function save(value) {
      var _this = this;

      this.originalValue = value;
      setTimeout(function () {
        _this.isActive = false;
      });
    }
  }
});

exports.default = _default;
//# sourceMappingURL=index.js.map