"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = component;

function component(options) {
  return options;
}
//# sourceMappingURL=component.js.map