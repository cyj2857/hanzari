"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VSnackbar", {
  enumerable: true,
  get: function get() {
    return _VSnackbar.default;
  }
});
exports.default = void 0;

var _VSnackbar = _interopRequireDefault(require("./VSnackbar"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VSnackbar.default;
exports.default = _default;
//# sourceMappingURL=index.js.map