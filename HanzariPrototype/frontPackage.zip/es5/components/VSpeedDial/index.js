"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VSpeedDial", {
  enumerable: true,
  get: function get() {
    return _VSpeedDial.default;
  }
});
exports.default = void 0;

var _VSpeedDial = _interopRequireDefault(require("./VSpeedDial"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VSpeedDial.default;
exports.default = _default;
//# sourceMappingURL=index.js.map