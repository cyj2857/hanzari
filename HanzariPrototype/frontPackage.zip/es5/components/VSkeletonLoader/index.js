"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VSkeletonLoader", {
  enumerable: true,
  get: function get() {
    return _VSkeletonLoader.default;
  }
});
exports.default = void 0;

var _VSkeletonLoader = _interopRequireDefault(require("./VSkeletonLoader"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VSkeletonLoader.default;
exports.default = _default;
//# sourceMappingURL=index.js.map