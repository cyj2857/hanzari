"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VSystemBar", {
  enumerable: true,
  get: function get() {
    return _VSystemBar.default;
  }
});
exports.default = void 0;

var _VSystemBar = _interopRequireDefault(require("./VSystemBar"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VSystemBar.default;
exports.default = _default;
//# sourceMappingURL=index.js.map