"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VOverlay", {
  enumerable: true,
  get: function get() {
    return _VOverlay.default;
  }
});
exports.default = void 0;

var _VOverlay = _interopRequireDefault(require("./VOverlay"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VOverlay.default;
exports.default = _default;
//# sourceMappingURL=index.js.map