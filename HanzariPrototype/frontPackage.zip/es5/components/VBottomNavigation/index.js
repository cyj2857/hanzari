"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VBottomNavigation", {
  enumerable: true,
  get: function get() {
    return _VBottomNavigation.default;
  }
});
exports.default = void 0;

var _VBottomNavigation = _interopRequireDefault(require("./VBottomNavigation"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VBottomNavigation.default;
exports.default = _default;
//# sourceMappingURL=index.js.map