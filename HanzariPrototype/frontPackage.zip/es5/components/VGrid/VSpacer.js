"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

require("../../../src/components/VGrid/_grid.sass");

var _helpers = require("../../util/helpers");

var _default = (0, _helpers.createSimpleFunctional)('spacer', 'div', 'v-spacer');

exports.default = _default;
//# sourceMappingURL=VSpacer.js.map