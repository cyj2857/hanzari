"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

require("../../../src/components/VGrid/_grid.sass");

var _grid2 = _interopRequireDefault(require("./grid"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = (0, _grid2.default)('flex');

exports.default = _default;
//# sourceMappingURL=VFlex.js.map