"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VBanner", {
  enumerable: true,
  get: function get() {
    return _VBanner.default;
  }
});
exports.default = void 0;

var _VBanner = _interopRequireDefault(require("./VBanner"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VBanner.default;
exports.default = _default;
//# sourceMappingURL=index.js.map