"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VOverflowBtn", {
  enumerable: true,
  get: function get() {
    return _VOverflowBtn.default;
  }
});
exports.default = void 0;

var _VOverflowBtn = _interopRequireDefault(require("./VOverflowBtn"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VOverflowBtn.default;
exports.default = _default;
//# sourceMappingURL=index.js.map