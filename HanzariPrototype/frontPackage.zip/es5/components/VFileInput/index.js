"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VFileInput", {
  enumerable: true,
  get: function get() {
    return _VFileInput.default;
  }
});
exports.default = void 0;

var _VFileInput = _interopRequireDefault(require("./VFileInput"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VFileInput.default;
exports.default = _default;
//# sourceMappingURL=index.js.map