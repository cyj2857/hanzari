"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VTextarea", {
  enumerable: true,
  get: function get() {
    return _VTextarea.default;
  }
});
exports.default = void 0;

var _VTextarea = _interopRequireDefault(require("./VTextarea"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VTextarea.default;
exports.default = _default;
//# sourceMappingURL=index.js.map