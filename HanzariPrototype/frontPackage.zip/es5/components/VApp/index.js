"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VApp", {
  enumerable: true,
  get: function get() {
    return _VApp.default;
  }
});
exports.default = void 0;

var _VApp = _interopRequireDefault(require("./VApp"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VApp.default;
exports.default = _default;
//# sourceMappingURL=index.js.map