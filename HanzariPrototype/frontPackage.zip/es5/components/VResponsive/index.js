"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VResponsive", {
  enumerable: true,
  get: function get() {
    return _VResponsive.default;
  }
});
exports.default = void 0;

var _VResponsive = _interopRequireDefault(require("./VResponsive"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VResponsive.default;
exports.default = _default;
//# sourceMappingURL=index.js.map