"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VBtnToggle", {
  enumerable: true,
  get: function get() {
    return _VBtnToggle.default;
  }
});
exports.default = void 0;

var _VBtnToggle = _interopRequireDefault(require("./VBtnToggle"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VBtnToggle.default;
exports.default = _default;
//# sourceMappingURL=index.js.map