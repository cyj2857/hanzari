"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VAutocomplete", {
  enumerable: true,
  get: function get() {
    return _VAutocomplete.default;
  }
});
exports.default = void 0;

var _VAutocomplete = _interopRequireDefault(require("./VAutocomplete"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VAutocomplete.default;
exports.default = _default;
//# sourceMappingURL=index.js.map