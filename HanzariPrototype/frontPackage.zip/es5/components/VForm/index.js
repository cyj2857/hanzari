"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VForm", {
  enumerable: true,
  get: function get() {
    return _VForm.default;
  }
});
exports.default = void 0;

var _VForm = _interopRequireDefault(require("./VForm"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VForm.default;
exports.default = _default;
//# sourceMappingURL=index.js.map