"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VLazy", {
  enumerable: true,
  get: function get() {
    return _VLazy.default;
  }
});
exports.default = void 0;

var _VLazy = _interopRequireDefault(require("./VLazy"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VLazy.default;
exports.default = _default;
//# sourceMappingURL=index.js.map