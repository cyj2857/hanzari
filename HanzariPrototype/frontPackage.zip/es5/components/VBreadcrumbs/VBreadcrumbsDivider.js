"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helpers = require("../../util/helpers");

var _default = (0, _helpers.createSimpleFunctional)('v-breadcrumbs__divider', 'li');

exports.default = _default;
//# sourceMappingURL=VBreadcrumbsDivider.js.map