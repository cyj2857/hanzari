"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VCounter", {
  enumerable: true,
  get: function get() {
    return _VCounter.default;
  }
});
exports.default = void 0;

var _VCounter = _interopRequireDefault(require("./VCounter"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VCounter.default;
exports.default = _default;
//# sourceMappingURL=index.js.map