"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VInput", {
  enumerable: true,
  get: function get() {
    return _VInput.default;
  }
});
exports.default = void 0;

var _VInput = _interopRequireDefault(require("./VInput"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VInput.default;
exports.default = _default;
//# sourceMappingURL=index.js.map