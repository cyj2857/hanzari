"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "VAvatar", {
  enumerable: true,
  get: function get() {
    return _VAvatar.default;
  }
});
exports.default = void 0;

var _VAvatar = _interopRequireDefault(require("./VAvatar"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _VAvatar.default;
exports.default = _default;
//# sourceMappingURL=index.js.map