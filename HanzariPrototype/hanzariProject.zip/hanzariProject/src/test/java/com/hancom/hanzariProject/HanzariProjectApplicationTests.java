package com.hancom.hanzariProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HanzariProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
